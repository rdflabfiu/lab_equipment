// Copyright (C) 2015
// KUKA Roboter GmbH, Germany. All Rights Reserved

Copy your RSI Context configuration files into this folder.