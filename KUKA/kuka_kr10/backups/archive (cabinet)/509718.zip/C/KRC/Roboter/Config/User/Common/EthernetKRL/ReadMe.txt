// Copyright (C) 2015
// KUKA Roboter GmbH, Germany. All Rights Reserved

Copy your EthernetKRL configuration files into this folder.